/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

/**
 *
 * @author danie
 */
public interface Tecnologia {
    public void Prender();

  public void Apagar();

  public String Tipo();
}
